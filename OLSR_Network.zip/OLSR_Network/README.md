# CPE400
CPE400 Semester Project

# Specifications
OLSR‐based Wireless mesh network design with Raspberry Pies
    a. System development 
    b. Experiment design 
    c. Results 

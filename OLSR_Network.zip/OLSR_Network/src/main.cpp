#include "../include/olsr.h"
#include <iostream>

using namespace std;

int main()
{
    OLSR myNetwork;
	Node myNode;
    return 0;
}
